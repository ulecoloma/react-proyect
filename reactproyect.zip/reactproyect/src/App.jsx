import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'
import Header from './components/Header/header'
import Footer from './components/Footer/Footer'
import Titulo from './components/Titulo/Titulo'
import Zweihander from './components/Zweihander/Zweihander'
import Descripcion from './components/Descripcion/Descripcion'
import Dragon from './components/Dragon/Dragon'
import Alabarda from './components/Alabarda/Alabarda'
import Claymore from './components/Claymore/Claymore'
import Humo from './components/Humo/Humo'
import Gemela from './components/Gemela/Gemela'
import Palabra from './components/Palabra/Palabra'
import Letras from './components/Letras/Letras'
import Caracteres from './components/Caracteres/Caracteres'


function App() {
  const [count, setCount] = useState(0)

  return (
    <>
    <div>
      <Header></Header>
    </div>

    <div>
      <Titulo></Titulo>
    </div>

    <div>
    <Zweihander></Zweihander>
    <Descripcion></Descripcion>
    <Dragon></Dragon>
    <Alabarda></Alabarda>
    </div>

    <div>
    <Claymore></Claymore>
    </div>

    <div>
      <Humo></Humo>
    </div>
    <div>
      <Gemela></Gemela>
    </div>

    <div>
    <Palabra></Palabra>
    </div>

    <div>
      <Letras></Letras>
    </div>

    <div>
      <Caracteres></Caracteres>
    </div>

    
    <div>
      <Footer></Footer>
    </div>
     
    </>
  )
}

export default App
