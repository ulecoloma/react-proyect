import './Gemela.css'
export default function Gemela(){
    const Gemela = '/Humo.png'
    return(
        <>
        <div className='container8'>
        <a href="/" className='gemela'><img src={Gemela} alt='Logo'/></a>
        </div>
        
        </>
    )
} 