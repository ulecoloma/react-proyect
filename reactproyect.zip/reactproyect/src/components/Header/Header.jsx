import './Header.css'
import Logo from '../Logo/Logo'
const Header = () => {
    return (
        <div>
            <header className='navbar'>
            <div className='logo'><Logo /></div> 
            </header>
            <h1 className='tilt'>Tienda Solaire</h1>
            
            <ul className='menu1'>
                <li><a href="#"></a>Inicio</li>
            </ul>

            <ul className='menu2'>
                <li><a href="#"></a>Mi Cuenta</li>
            </ul>

            <ul className='menu3'>
                <li><a href="#"></a>Carrito</li>
            </ul>
            
        </div>
        
    )
}

export default Header;