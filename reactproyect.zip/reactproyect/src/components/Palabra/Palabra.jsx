import './Palabra.css'
const Palabra = () => {
    return (
        <>
        <p className='des4'>Claymore</p>
        </>

    )
}

export default Palabra