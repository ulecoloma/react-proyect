import './Claymore.css'
export default function Claymore(){
    const Claymore = '/Claymore.png'
    return(
        <>
        <div className='container6'>
        <a href="/" className='clay'><img src={Claymore} alt='Logo'/></a>
        </div>
        
        </>
    )
} 