import './Descripcion.css'
const Descripcion = () => {
    return (
        <>
        <p className='des'>Zweihander</p>
        <p className='des2'>Alabarda</p>
        <p className='des3'>Alabarda Dragón</p>
        </>

    )
}

export default Descripcion