import './Footer.css'
import Solaire from '../Solaire/Solaire'
const Footer =() =>{
    return (

        <footer className='piepagina'>
            <div className='Solaire'><Solaire /></div> 
            <div className='footermenu'>
            <ul className='footer1'>
                <li><a href="#"></a>Contacto</li>
            </ul>

            <ul className='footer2'>
                <li><a href="otra_pagina.index"></a>Redes sociales</li>
            </ul>

            <ul className='footer3'>
                <li><a href="#"></a>Ayuda</li>
                <link rel="stylesheet" href="" />
            </ul>

            </div>
        </footer>
    )
}

export default Footer