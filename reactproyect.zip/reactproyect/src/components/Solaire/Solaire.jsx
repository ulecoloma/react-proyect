import './Solaire.css'
export default function Solaire(){
    const Solaire = '/Solaire.png'
    return(
        <>
        <a href="/" className='solaire'><img src={Solaire} alt='Logo'/></a>
        </>
    )
}