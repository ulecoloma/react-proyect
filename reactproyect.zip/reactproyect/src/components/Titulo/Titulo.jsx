import './Titulo.css'
const Titulo =() =>{
    return (
        <>
        <div className='container'>
            <h1 className='titulo1'>Bienvenido</h1>
            <p className='titulo2'>Nuestro catalogo - Lo mas vendido - Calidad alta - Calidad Media - Calidad Baja 
                - Espadas Tipo Dragon - Espadas tipo Mago - Otros </p>
        </div>


        </>
    )
}

export default Titulo