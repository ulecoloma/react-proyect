import './Caracteres.css'
const Caracteres = () => {
    return (
        <>
        <p className='des6'>Ultra espadón del humo</p>
        </>

    )
}

export default Caracteres