import './Dragon.css'
export default function Dragon(){
    const Dragon = '/Dragon.png'
    return(
        <>
        <div className='container3'>
        <a href="/" className='miDragon'><img src={Dragon} alt='Logo'/></a>
        </div>
        
        </>
    )
}
