import './logo.css'
export default function Logo(){
    const Logo = '/Logo.png'
    return(
        <>
        <a href="/" className='logo'><img src={Logo} alt='Logo'/></a>
        </>
    )
}