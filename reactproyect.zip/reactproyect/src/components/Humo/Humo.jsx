import './Humo.css'
export default function Humo(){
    const Humo = '/Espada.png'
    return(
        <>
        <div className='container7'>
        <a href="/" className='humo'><img src={Humo} alt='Logo'/></a>
        </div>
        
        </>
    )
} 