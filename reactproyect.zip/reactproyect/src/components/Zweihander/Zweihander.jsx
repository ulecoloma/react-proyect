import './Zweihander.css'
export default function Zweihander(){
    const Zweihander = '/Zweihander.png'
    return(
        <>
        <div className='container2'>
        <a href="/" className='mizwei'><img src={Zweihander} alt='Logo'/></a>
        </div>
        
        </>
    )
}
