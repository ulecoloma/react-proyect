import './Letras.css'
const Letras = () => {
    return (
        <>
        <p className='des5'>Espadas Gemelas</p>
        </>

    )
}

export default Letras