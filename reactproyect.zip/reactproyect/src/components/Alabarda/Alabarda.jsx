import './Alabarda.css'
export default function Alabarda(){
    const Alabarda = '/Alabarda.png'
    return(
        <>
        <div className='container4'>
        <a href="/" className='miAla'><img src={Alabarda} alt='Logo'/></a>
        </div>
        
        </>
    )
}